-- Starfall Mods community backend
-- In Supabase: SQL Editor -> New query -> paste this file -> Run

create table if not exists public.reviews (
  id bigint generated always as identity primary key,
  display_name text not null check (char_length(display_name) between 2 and 24),
  rating int not null check (rating between 1 and 5),
  review_text text not null check (char_length(review_text) between 3 and 500),
  created_at timestamptz not null default now()
);

create table if not exists public.feedback (
  id bigint generated always as identity primary key,
  display_name text not null check (char_length(display_name) between 2 and 24),
  message text not null check (char_length(message) between 3 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.site_stats (
  id int primary key default 1 check (id = 1),
  downloads bigint not null default 0
);
insert into public.site_stats (id, downloads) values (1, 0) on conflict (id) do nothing;

alter table public.reviews enable row level security;
alter table public.feedback enable row level security;
alter table public.site_stats enable row level security;

create policy "Reviews are public to read" on public.reviews
  for select using (true);
create policy "Visitors can submit reviews" on public.reviews
  for insert with check (
    char_length(display_name) between 2 and 24
    and char_length(review_text) between 3 and 500
    and rating between 1 and 5
  );

create policy "Feedback is public to read" on public.feedback
  for select using (true);
create policy "Visitors can submit feedback" on public.feedback
  for insert with check (
    char_length(display_name) between 2 and 24
    and char_length(message) between 3 and 1000
  );

create policy "Download count is public to read" on public.site_stats
  for select using (true);

create or replace function public.record_download()
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare new_count bigint;
begin
  update public.site_stats
  set downloads = downloads + 1
  where id = 1
  returning downloads into new_count;
  return new_count;
end;
$$;

grant select, insert on public.reviews to anon, authenticated;
grant select, insert on public.feedback to anon, authenticated;
grant select on public.site_stats to anon, authenticated;
grant execute on function public.record_download() to anon, authenticated;
