/*
  Supabase project settings go here.
  These two values are public browser settings. Use the project's anon/publishable key,
  NEVER a service_role or secret key.
*/
window.STARFALL_SUPABASE_URL = "HIER_DEINE_SUPABASE_PROJECT_URL";
window.STARFALL_SUPABASE_ANON_KEY = "HIER_DEIN_SUPABASE_ANON_ODER_PUBLISHABLE_KEY";
